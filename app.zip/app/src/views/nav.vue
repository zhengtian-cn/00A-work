<template>
    <div>
        <router-view/>
        <navMenu></navMenu>
    </div>
</template>

<script>
    import navMenu from '@/components/navMenu.vue'
    export default {
        name: "nav",
        components: {
            navMenu
        }
    }
</script>

<style scoped>

</style>